
var ApiGen = ApiGen || {};
ApiGen.elements = [["f","exception_error_handler()"],["f","filter_request()"],["f","filter_session()"],["f","format_stack_trace()"]];
